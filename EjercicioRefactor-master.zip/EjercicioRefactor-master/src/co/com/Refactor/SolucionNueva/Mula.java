package co.com.Refactor.SolucionNueva;

public class Mula extends Vehiculo{
    public Mula() {
        super(95, 96, 110, "mula");
    }
}
