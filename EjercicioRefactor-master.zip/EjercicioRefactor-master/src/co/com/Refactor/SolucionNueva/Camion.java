package co.com.Refactor.SolucionNueva;

public class Camion extends Vehiculo{
    public Camion() {
        super(75, 76, 95, "camión");
    }
}
