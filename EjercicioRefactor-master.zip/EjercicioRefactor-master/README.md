# Ejercicio Refactor

Desarrollo ejercicio de refactor, principios SOLID y buenas practicas de desarrollo dentro del desarrollo del BootCamp de desarrollo web BackEnd de MAKAIA.

## El ejercicio consistía en tomar un proyecto y refactorizarlo utilizando buenas prácticas tratando de minimizar el código repetido, haciéndo mas entendible y claro.

## Para observar el desarrollo de este ejercicio se tienen dos paquetes en el proyecto, uno con la solución incial dada y otro con la solución nueva, ambos con su respectivo método main a fin de verificar la similitud de los resultados en ambos casos.

## Para el desarrollo de este ejercicio se trabajó en grupo para la cosntrucción de la solución nueva y el grupo fue integrado por:
  * Ana María Vásquez
  * Christian Toro
  * Maria Alejandra De Ossa Duque
  * Paula Andrea Martinez
  * Paula Munera
  * Yeisson Augusto Vahos Cortes
## Participantes del BootCamp de desarrollo web BackEnd de MAKAIA.
