package co.com.Refactor.SolucionNueva;

public class Carro extends Vehiculo{
    public Carro() {
        super(65, 66, 85, "carro");
    }
}
